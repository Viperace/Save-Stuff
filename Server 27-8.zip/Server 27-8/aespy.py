#coding:utf-8
from Crypto.Cipher import AES
import base64

class AesCrypt:

    key ='61MjU1M0F6OUZ.3z'
    iv = '1234567812345678'
    # 加密
    def pyencrypt(self,data):
        PADDING = '\0'
        pad_it = lambda s: s+(16 - len(s)%16)*PADDING
        generator = AES.new(self.key, AES.MODE_CBC, self.iv)
        crypt = generator.encrypt(pad_it(data))
        cryptedStr = base64.b64encode(crypt)
        return cryptedStr
    # 解密
    def pydecrypt(self,data):
        generator = AES.new(self.key, AES.MODE_CBC, self.iv)
        recovery = generator.decrypt(base64.decodestring(data))
        # 这里要去掉后面的/x00这个如果不去掉会导致错误会产生几个空的东西
        # 用repr包装过的东西要用eval在转成对象否则会出现''这个符号在前后
        recovery=repr(recovery)

        try:
            # print 'ppp'
            return recovery[1:recovery.index('\\x00')]
        except:
            print 'ok'
            return eval(recovery)

class AesCrypt_tow:

    key ='61MjU1M0F6OUV.9z'
    iv = '1234567812345678'
    # 加密
    def pyencrypt(self,data):
        PADDING = '\0'
        pad_it = lambda s: s+(16 - len(s)%16)*PADDING
        generator = AES.new(self.key, AES.MODE_CBC, self.iv)
        crypt = generator.encrypt(pad_it(data))
        cryptedStr = base64.b64encode(crypt)
        return cryptedStr
    # 解密
    def pydecrypt(self,data):
        generator = AES.new(self.key, AES.MODE_CBC, self.iv)
        recovery = generator.decrypt(base64.decodestring(data))
        # 这里要去掉后面的/x00这个如果不去掉会导致错误会产生几个空的东西
        # 用repr包装过的东西要用eval在转成对象否则会出现''这个符号在前后
        recovery=repr(recovery)

        try:
            print 'ppp'
            return recovery[1:recovery.index('\\x00')]
        except:
            print 'ok'
            return eval(recovery)

if __name__=='__main__':
     uvv=AesCrypt().pyencrypt('ycq')
     print uvv
     print AesCrypt().pydecrypt("iXBLFcUH4S5vyjbCTSlQaXmHNC6+gQdwtphTRB24XC5lJWHMTO+2Fx8MzlQUvVHE")
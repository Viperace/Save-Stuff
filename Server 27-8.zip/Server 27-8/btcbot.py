#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import random
import sys
import platform
from urllib import unquote
import datetime, time
from datetime import timedelta
import telegram
import redis

reload(sys)
sys.setdefaultencoding('utf-8')
# django------------------------------------------------------------>
def isLinuxSystem():
    return 'Linux' in platform.system()


if isLinuxSystem():
    sys.path.append(r'/var/www/html/btc')
    os.chdir(r'/var/www/html/btc')
else:
    #sys.path.append(r'J:\2017work\django\2018work\telegrambot\btc')
    sys.path.append(r'D:\Telegram Projects\TestModels 2\btc')
    #os.chdir(r'J:\2017work\django\2018work\telegrambot\btc')
    os.chdir(r'D:\Telegram Projects\TestModels 2\btc')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'btc.settings')
import django

django.setup()
# 当前时间时区
from django.utils import timezone
# 这里显示不正常也没关系其实他已经在操作django模型只是没目录看起来会报错.但是目录已经通过上面的配置引入
from btchtm.models import Extend_user, bettingup, bettingdwon, winning, whistory, netnumber, user_settings
from django.contrib.auth.models import User
#django------------------------------------------------------------>

#启动内存数据库
pool = redis.ConnectionPool(host='localhost', port=6379, decode_responses=True)
#pool = redis.ConnectionPool(host='155.254.49.141',password='#$dsd!4ds', port=6379, decode_responses=True)
redisdb = redis.Redis(connection_pool=pool)

import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, ConversationHandler, \
    RegexHandler
from telegram.ext.dispatcher import run_async
from telegram import ReplyKeyboardMarkup

import pandas as pd
import pytz
from PIL import Image
import PIL
from resizeimage import resizeimage
import numpy as np
from MyLocale import TranslateString, Language  # Localization
from BitcoinPayment import BitcoinPayment

# 记录版本
# python-resize-image-1.1.11
# Pillow  5.2.0
# requests  2.11.1

#bug探测
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# 定义全局变量
myglobal = ''

read_winning_count = 0  # Count how many times 'winning' has been called


#游戏时间
def gamesStartTime():
    seconds = redisdb.ttl('gamesStart')
    if seconds:
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return str(("%02d:%02d" % (m, s)))
    else:
        return '00:00'

#等待开奖时间
def gamesYeidTime():
    seconds = redisdb.ttl('gamesYeid')
    if seconds:
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return str(("%02d:%02d" % (m, s)))
    else:
        return '00:00'

#聊天时间
def gamesEndTime():
    seconds = redisdb.ttl('gamesEnd')
    if seconds:
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return str(("%02d:%02d" % (m, s)))
    else:
        return '00:00'


# 是否可以投注的装饰器
def isbet(inputfuc):
    def fuc(bot,update):
        gamesYeid = str(redisdb.ttl('gamesYeid'))
        gamesEnd = str(redisdb.ttl('gamesEnd'))
        gameBet = str(redisdb.get('gameBet'))

        user_lang = get_user_language(update.message.chat_id)

        if str(gameBet) == 'yes':
            starttime = gamesStartTime()
            update.message.reply_text(translator.look_up('Betting time, good luck! \nTime to stop betting :', user_lang) + starttime+ translator.look_up(' sec', user_lang))
            inputfuc(bot,update)
            # return True
        else:
            if gamesYeid != 'None':
                yeidtime = gamesYeidTime()
                update.message.reply_text(translator.look_up( 'Bet no longer accepted. Please wait for result announcement\nTime to result announcement :', user_lang) + yeidtime+translator.look_up(' sec', user_lang))
            elif gamesEnd != 'None':
                endtime = gamesEndTime()
                update.message.reply_text(translator.look_up(
                    'This round is over. Please check your record if you have placed bet\nTime to next round :', user_lang) + endtime+translator.look_up(' sec', user_lang))
            # return False
    return fuc


#start启动的屏幕键盘
# 通用的下键盘
def downkeydate(bot, update):
    user_lang = get_user_language(update.message.chat_id)
    print "downkey " + str(user_lang)

    #reply_keyboard = [['开始下注', '开 奖', '充 值', '收 款'], ['中 文', '翻 墙'], ['游戏规则'], ['邀请朋友一起玩']]
    reply_keyboard = [[translator.look_up('Start Bet', user_lang),
                      translator.look_up('Result', user_lang),
                      translator.look_up('Topup', user_lang),
                      translator.look_up('Cash out', user_lang)],
                      [translator.look_up('中 文 / ENGLISH', user_lang), translator.look_up('VPN', user_lang)],
                      [translator.look_up('Game rules', user_lang)],
                      [translator.look_up('Invite others', user_lang)]]
    markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)
    # print markup
    #键盘按键
    update.message.reply_text(translator.look_up('Welcome to Bitcoin Fun Hour', user_lang), reply_markup=markup)


def screendata(chat_id, update):
    user_lang = get_user_language(update.message.chat_id)

    # 屏幕按键
    keyboard = [[InlineKeyboardButton(unquote(translator.look_up('How to play', user_lang)), callback_data='menuhelp'), ],
                [InlineKeyboardButton(translator.look_up('How to topup', user_lang), callback_data='menuaddpoint')],
                [InlineKeyboardButton(translator.look_up('Start Bet', user_lang), callback_data='gamestart')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text(translator.look_up('Hi, I am Bitcoin Bet Bot', user_lang), reply_markup=reply_markup, )


# 买涨

def touzhuup(bot, update):
    user_lang = get_user_language(update.message.chat_id)

    myglobal = 0
    reply_keyboard = [['↑+100', '↑+200', '↑+500', '↑+1K', '↑+3K'],
                      [translator.look_up('↑+All in', user_lang), translator.look_up('Bet info', user_lang)],
                      [translator.look_up('↑Bet up', user_lang), translator.look_up('↓Bet down', user_lang)],
                      [translator.look_up('✖↑Cancel', user_lang)], [translator.look_up('♜ Homepage', user_lang)]]
    markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)

    try:
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        print Extend_userdata.xcoin
        update.message.reply_text(translator.look_up('Your balance is : %s x-coin\nSelect your bet amount',
                                                     user_lang) % (str(Extend_userdata.xcoin)), reply_markup=markup)
    except:
        print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"


#买跌
def touzhudown(bot, update):
    user_lang = get_user_language(update.message.chat_id)

    myglobal = 1
    reply_keyboard = [['↓+100', '↓+200', '↓+500', '↓+1K', '↓+3K'],
                      [translator.look_up('↓+All in', user_lang), translator.look_up('Bet info', user_lang)],
                      [translator.look_up('↑Bet up', user_lang), translator.look_up('↓Bet down', user_lang)],
                      [translator.look_up('✖↓Cancel', user_lang)], [translator.look_up('♜ Homepage', user_lang)]]
    markup = ReplyKeyboardMarkup(reply_keyboard, resize_keyboard=True)
    try:
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        print Extend_userdata.xcoin
        update.message.reply_text(translator.look_up('Your balance is : %s x-coin\nSelect your bet amount',
                                                     user_lang) % (str(Extend_userdata.xcoin)), reply_markup=markup)
    except:
        print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"


#买涨
@isbet
def buyhandleup(bot,update):
    usermessage = update.message.text
    usermessage = str(usermessage).split('↑+')
    if usermessage[1] == '100':
        mesgbuy(update, 0, 100)
    elif usermessage[1] == '200':
        mesgbuy(update, 0, 200)
    elif usermessage[1] == '500':
        mesgbuy(update, 0, 500)
    elif usermessage[1] == '1K':
        mesgbuy(update, 0, 1000)
    elif usermessage[1] == '3K':
        mesgbuy(update, 0, 3000)
    elif usermessage[1] == '全梭了' or usermessage[1] == 'All in':
        try:
            Extend_userdata=Extend_user.objects.get(telid=update.message.chat_id)
            mesgbuy(update, 0, Extend_userdata.xcoin)
        except:
            print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"


#买跌
@isbet
def buyhandledown(bot,update):
    usermessage = update.message.text
    usermessage = str(usermessage).split('↓+')
    if usermessage[1] == '100':
        mesgbuy(update, 1, 100)
    elif usermessage[1] == '200':
        mesgbuy(update, 1, 200)
    elif usermessage[1] == '500':
        mesgbuy(update, 1, 500)
    elif usermessage[1] == '1K':
        mesgbuy(update, 1, 1000)
    elif usermessage[1] == '3K':
        mesgbuy(update, 1, 3000)
    elif usermessage[1] == '全梭了' or usermessage[1] == 'All in':
        try:
            Extend_userdata=Extend_user.objects.get(telid=update.message.chat_id)
            mesgbuy(update, 1, Extend_userdata.xcoin)
        except:
            print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"


def mesgbuy(update, isupdown, betquota):
    try:
        user_lang = get_user_language(update.message.chat_id)
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        if betquota>=100:
            if isupdown == 0:
                if Extend_userdata.xcoin - betquota >= 0:
                    # 买涨
                    try:
                        bettingup.objects.get(telid=update.message.chat_id)
                    except:
                        bettingup.objects.get_or_create(userid=Extend_userdata.ext_user_id,
                                                        telid=Extend_userdata.telid,
                                                        betquota=0, )
                    Extend_userdata.xcoin = Extend_userdata.xcoin - int(betquota)
                    Extend_userdata.save()
                    bettingupdata = bettingup.objects.get(telid=update.message.chat_id)
                    bettingupdata.betquota = bettingupdata.betquota + betquota
                    bettingupdata.save()
                    update.message.reply_text(
                        translator.look_up('Your balance is : %s x-coin\nBet UP↑ Total Amount %s',
                                           user_lang) % (str(Extend_userdata.xcoin), str(bettingupdata.betquota)))
                else:
                    update.message.reply_text(translator.look_up('Your balance is : %s x-coin\nInsufficient balance to place bet', user_lang) % (str(Extend_userdata.xcoin)))

            # 买跌
            if isupdown == 1:
                if Extend_userdata.xcoin - betquota >= 0:
                    try:
                        bettingdwon.objects.get(telid=update.message.chat_id)
                    except:
                        bettingdwon.objects.get_or_create(userid=Extend_userdata.ext_user_id,
                                                          telid=Extend_userdata.telid,
                                                          betquota=0, )
                    Extend_userdata.xcoin = Extend_userdata.xcoin - int(betquota)
                    Extend_userdata.save()
                    bettingdwondata = bettingdwon.objects.get(telid=update.message.chat_id)
                    bettingdwondata.betquota = bettingdwondata.betquota + betquota
                    bettingdwondata.save()
                    update.message.reply_text(
                        translator.look_up('Your balance is : %s x-coin\nBet DOWN↓ Total Amount %s x-coin',
                                           user_lang) % (str(Extend_userdata.xcoin), str(bettingdwondata.betquota)))
                else:
                    update.message.reply_text(translator.look_up('Your balance is : %s x-coin\nInsufficient balance to place bet', user_lang) % (str(Extend_userdata.xcoin)))
        else:
            update.message.reply_text(translator.look_up('Your balance is : %s x-coin\nMinimum bet requirement is 100 x-coin', user_lang) % (str(Extend_userdata.xcoin)))
    except:
        print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"

# 取消买涨
@isbet
def cancelup(bot,update):
    user_lang = get_user_language(update.message.chat_id)

    try:
        bettingupdata = bettingup.objects.get(telid=update.message.chat_id)
    except Exception, e:
        print e
    try:
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        Extend_userdata.xcoin = Extend_userdata.xcoin + int(bettingupdata.betquota)
        Extend_userdata.save()
        bettingupdata.delete()
        update.message.reply_text(translator.look_up('You cancel all up bet.\nReturn %s x-coin', user_lang) % (bettingupdata.betquota))
    except Exception, e:
        print e
        update.message.reply_text(translator.look_up('You have not place any bet. Nothing to cancel', user_lang))


# 取消买跌
@isbet
def canceldown(bot,update):
    user_lang = get_user_language(update.message.chat_id)

    try:
        bettingdwondata = bettingdwon.objects.get(telid=update.message.chat_id)
    except Exception, e:
        print e
    try:
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        Extend_userdata.xcoin = Extend_userdata.xcoin + int(bettingdwondata.betquota)
        Extend_userdata.save()
        bettingdwondata.delete()
        update.message.reply_text(translator.look_up('You cancel all down bet.\nReturn %s x-coin', user_lang) % (bettingdwondata.betquota))
    except Exception, e:
        print e
        update.message.reply_text(translator.look_up('You have not place any bet. Nothing to cancel', user_lang))


#和机器人对话
def echo(bot, update):
    user_lang = get_user_language(update.message.chat_id)

    isbet(update)
    """Echo the user message."""
    print update.message.text
    print update.message.chat_id
    # bot.send_message(chat_id=update.message.chat_id,text='<b>这是一张黄图</b><a href="http://www.w3school.com.cn/i/eg_tulip.jpg">link</a>', parse_mode=telegram.ParseMode.HTML)
    # update.message.reply_text(update.message.text ,photo='http://www.w3school.com.cn/i/eg_tulip.jpg')
    # bot.send_photo(chat_id=update.message.chat_id, photo='https://farm2.staticflickr.com/1680/24816754162_cbcf0268d7_c.jpg')
    # 注册被开启
    # openid = update.message.chat_id
    # bot.send_photo(chat_id=update.message.chat_id, photo='https://telegram.org/img/t_logo.png')
    if update.message.text == translator.look_up('♜ Homepage', user_lang):
        downkeydate(bot, update)
        screendata(update.message.chat_id, update)
    elif update.message.text == translator.look_up('Start Bet', user_lang):
        # keyboard = [[InlineKeyboardButton(unquote("客户端下注内容更精彩"), url='http://127.0.0.1:8000/sing/'),]]
        keyboard = [[InlineKeyboardButton(unquote("客户端下注内容更精彩"), url='http://192.168.1.104:8000'), ]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        update.message.reply_text(translator.look_up('Hi, I am Bitcoin Bet Bot', user_lang), reply_markup=reply_markup, )
        touzhuup(bot, update)
    # 买涨入口
    elif update.message.text == translator.look_up('↑Bet up', user_lang):
        touzhuup(bot, update)
    #买跌入口
    elif update.message.text == translator.look_up('↓Bet down', user_lang):
        touzhudown(bot, update)

    # 买涨
    elif str(update.message.text).split('+')[0] == '↑':
        buyhandleup(bot,update)
    # 买跌
    elif str(update.message.text).split('+')[0] == '↓':
        buyhandledown(bot,update)

    elif update.message.text == translator.look_up('Bet info', user_lang):
        betdetailed(bot,update)

    elif update.message.text == translator.look_up('✖↑Cancel', user_lang):
        cancelup(bot,update)

    elif update.message.text == translator.look_up('✖↓Cancel', user_lang):
        canceldown(bot,update)

    elif update.message.text == translator.look_up('Result', user_lang):
        reply_user_win_history(bot, update)

    elif update.message.text == translator.look_up('Topup', user_lang):
        BitcoinPayment.topup_process(bot, update, translator, user_lang)
        BitcoinPayment.show_payment_history(bot, update, translator, user_lang)
    elif update.message.text == translator.look_up('Cash out', user_lang):
        bothtml(bot, update)

    elif update.message.text == '中 文 / ENGLISH':
        # update.message.reply_text('https://t.me/zh_CN/462')
        # 切换语言
        print 'User change language'
        if user_lang == Language.SIMPLIFIED_CHINESE:
            set_user_language(update.message.chat_id, Language.ENGLISH, update)
        else:
            set_user_language(update.message.chat_id, Language.SIMPLIFIED_CHINESE, update)
    elif update.message.text == translator.look_up('VPN', user_lang):
        bot.send_message(chat_id=update.message.chat_id,
                         text='<a href="https://t.me/proxy?server=155.254.49.141&port=443&secret=a0cbcef5a486d9636472ac27f8e11a9d">点这里自动安装到您的手机</a>\n<b>Telegram专用翻墙工具,永久高速免费,三天会更新一次,请按时回来更新,请不要把代理工具随意分享,人多了您就慢了切记</b>',
                         parse_mode=telegram.ParseMode.HTML)
        pass
    elif update.message.text == translator.look_up('Game rules', user_lang):
        bot.send_message(chat_id=update.message.chat_id,
                         text="【游戏规则】" 
                                "\n比特娱乐每五分钟一期，全天24小时不停开放。 第3分钟开奖，休息2分钟。"
                                "预测比特币官网指数在未来三分钟的趋势，上或下。"
                                "\n"
                                "\n【开奖，赔率】"
                                "\n✓ 每期开局时，机器人读取官方网站的比特币对美金指数。开奖时，再次读取此指数。"
                                "若开奖指数高于开局指数，开奖结果为〔上〕，低于为〔下〕，同等为〔平〕。"
                                "\n✓ 玩家可任意下注〔上〕或〔下〕。"
                                "\n✓ 中奖赔率随玩家人数而变。赔率计算为“无中奖家总注码”除于“中奖家总注码”。"
                                "\n✓ 庄家抽成为奖金的3%"
                                "\n✓ 若开奖结果为〔平〕，原价退还所有玩家注码"
                                "\n✓ 若任何一边〔上〕或〔下〕无玩家下注，此局无效，原价退还所有玩家注码"
                                "\n"
                                "\n【认证与公信】"
                                "\n✓ 比特娱乐采取的比特币指数是从官网"
                         '<a href="https://www.coindesk.com/">coindesk</a>'
                              "抽取。数字每15秒更新，24小时不断。玩家可到主页认证（请注意查询Bitcoin大字）。"
                                "\n✓ 比特娱乐设置机器人赌博平台，作为庄家，公平公正为玩家提供比特币数字的短期动态的玩法。",
                         parse_mode=telegram.ParseMode.HTML)
        pass


def bothtml(bot, update):
    """提现款 """
    Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
    password = random.randint(999, 900000000)

    # 在redisdb中生成临时密码10秒
    redisdb.set(Extend_userdata.username, password, ex=10)
    keyboard = [[InlineKeyboardButton(unquote("提现在10秒内进入"), url='http://155.254.49.141:8111/payment/sign/%s/%s/' % (
        Extend_userdata.username, password)), ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('以上消息仅限自己使用请勿转发!', reply_markup=reply_markup, )


def get_timezone_time(datetime_str):
    """Add 8 hours to current time, and return"""
    inputtime = datetime.datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
    inputtime += timedelta(hours=8)
    return str(inputtime)


def reply_user_win_history(bot, update, nunber_of_history=10):
    """Retrieve user whistory and reply to user most recent 10"""
    telid = update.message.chat_id
    user_lang = get_user_language(telid)

    try:
        userdata = Extend_user.objects.get(telid=telid)
        userid = userdata.ext_user_id
    except:
        print "Can't get ext_user_id for " + str(telid)
        return

    whistory_data = whistory.objects.filter(userid=userid)

    last_ten = whistory_data.order_by('-id')[:nunber_of_history]
    last_ten_in_ascending_order = reversed(last_ten)


    msg0 = translator.look_up("Your recent winners history", user_lang)
    bot.send_message(chat_id=update.message.chat_id, text=msg0)

    msg = translator.look_up("Time   |   x-coin", user_lang)
    for hist in last_ten_in_ascending_order:  # Actual content
        win_size = str(hist.quota)
        win_time = str(hist.bettime)
        win_time = get_timezone_time(win_time[0:19])

        msg += "\n" + win_time[0:16] + " ,  " + win_size     # win_time cap at hour:minute. Dont show second

    bot.send_message(chat_id=update.message.chat_id,
                     text=msg, parse_mode=telegram.ParseMode.HTML)


def explore_username(update):
    """Function to get the representative name of the user. Starting from
     username, firstname, last name till we got it"""
    nickname = update.message.from_user.username
    if nickname:
        return nickname

    first_name = update.message.from_user.first_name
    if first_name:
        return first_name

    last_name = update.message.from_user.last_name
    if last_name:
        return last_name


# 机器人开始
# https://telegram.me/vpnfreebot?start=abcde
def start(bot, update, args):
    telid = update.message.chat_id


    #-------------- 设置初期化 -------------->
    try:
        setting_data = user_settings.objects.get(telid=telid)  # 如果sql有记录就用
        if setting_data.language == 'ENGLISH':
            enumlang = Language.ENGLISH
        elif setting_data.language == 'SIMPLIFIED_CHINESE':
            enumlang = Language.SIMPLIFIED_CHINESE
        else:
            enumlang = Language.SIMPLIFIED_CHINESE
    except:  # 没有就查2用户的语言
        lang_code = update.effective_user.language_code
        print lang_code
        if 'ZH' in lang_code:
            user_settings.objects.get_or_create(telid=telid, language='SIMPLIFIED_CHINESE')
            enumlang = Language.SIMPLIFIED_CHINESE
        else:
            user_settings.objects.get_or_create(telid=telid, language='ENGLISH')
            enumlang = Language.ENGLISH

    set_user_language(telid=telid, enumlang=enumlang, update=update, show_msg=False)


    # -------------------------获取头像------------------------------->
    try:
        # 获取用户昵称
        nickname = explore_username(update)
        print "User's name is " + nickname

        # Extract avatar picture
        headimagefile_id=(update.message.from_user.get_profile_photos())['photos'][0][0]['file_id']
        print headimagefile_id
        # print bot.get_user_profile_photos(update.message.chat_id)
        photo_file = bot.get_file(headimagefile_id)
        headimage=str(telid)+'_head.jpg'
        photo_file.download('./media/'+headimage)

        # Convert pic to smaller size and store
        fd_img = open('./media/' + headimage, 'rb')
        img = Image.open(fd_img)
        img = resizeimage.resize_height(img, 96)
        img.save('./media/smallsize/'+headimage, img.format)
        print "done resizing and saving " + nickname
        fd_img.close()
    except:
        print "无头像. No avatar"
        pass
    # -------------------------获取头像------------------------------->

    try:
        Extend_user.objects.get(telid=telid)
        # 启动菜单
        screendata(telid, update)
        downkeydate(telid, update)

        # Update name
        user = Extend_user.objects.get(telid=telid)
        user.username = nickname
        user.save()
    except:
        print "Exception on user with nickname " + nickname
        try:
            password = random.randint(10000, 99999)

            if not nickname:
                name = createname()
            else:
                name = nickname
            print "this user has nickname " + nickname

            creatuser = User.objects.create_user(username=name, password=str(password))
            Extend_user.objects.get_or_create(ext_user_id=creatuser.id,
                                              username=str(name),
                                              pawword=password,
                                              telid=str(telid),
                                              openid=str(name) + str(telid),
                                              xcoin=0,
                                              btcaddress=str(name) + '_no',
                                              giveusermoney=300,
                                              notice='大家好',
                                              isreferee=False,
                                              userisrun=False, )
        except:
            print "Failure with nickname " + nickname + ". Telid: " + str(telid)
            User.objects.filter(id=creatuser.id).delete()

        try:
            username = str(args[0])
            Extend_userdata = Extend_user.objects.get(username=username)
        except:
            pass


#屏幕上的start button回调
def button(bot, update):
    query = update.callback_query

    try:
        user_lang = get_user_language(update.message.chat_id)
    except:
        print "Cant get user lang "
        user_lang = Language.SIMPLIFIED_CHINESE


    #游戏玩法
    if query.data == 'menuhelp':
        query.message.reply_text(unquote('这个比特币指数投注机器人三分钟开奖一次,他可以让您赢取很多比特币,只有买涨和买跌,只要您买中了就可以获得不同赔率的奖金,赶快参加投注赢去无限奖金'))

    if query.data == 'menuaddpoint':
        query.message.reply_text(unquote('这里是充值教学'))

    #pc如何使用教学
    if query.data == 'gamestart':
        # query.message.reply_text(unquote('开始下注'))
        query.message.reply_text(translator.look_up('Start Bet', user_lang))
        # bot.send_photo(chat_id=query.message.chat_id, photo=open('images/help/sstutio.jpg', 'rb'))


        # bot.edit_message_text(text="Selected option: {}".format(query.data),
        #                       chat_id=query.message.chat_id,
        #                       message_id=query.message.message_id)


#错误输出
def error(bot, update, error):
    """Log Errors caused by Updates."""
    logger.warning('Update "%s" caused error "%s"', update, error)

def betdetailed(bot,update):
    upbetquota=''
    downbetquota=''
    try:
        bettingupdata=bettingup.objects.get(telid=update.message.chat_id)
        upbetquota=str(bettingupdata.betquota)
    except:
        upbetquota='0'

    try:
        bettingdwondata=bettingdwon.objects.get(telid=update.message.chat_id)
        downbetquota=str(bettingdwondata.betquota)
    except:
        downbetquota='0'

    try:
        windata = winning.objects.all()[1]
        print windata.iloc[0]['userup']
        print windata.iloc[0]['userdown']
        print windata.iloc[0]['quota']
        print windata.iloc[0]['theodds']
    except:
        ""

    try:
        user_lang = get_user_language(update.message.chat_id)
        Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
        update.message.reply_text(translator.look_up('Your betting info\nBalance : %s x-coin\nCurrent round bet:\n↑Up bet %s x-coin\n↓Down bet %s x-coin \n',
                                                     user_lang) % (str(Extend_userdata.xcoin), upbetquota, downbetquota))
        update.message.reply_text(translator.look_up('Time left to wager: ', user_lang) + gamesStartTime() +
                                  translator.look_up('\nTime to announce result: ', user_lang) + gamesYeidTime() +
                                  translator.look_up('\nTime to next round: ', user_lang) + gamesEndTime())
    except:
        print "Cannot find telid? Extend_user.objects.get(telid=update.message.chat_id)"


# 工具类------------------------------------->


def createname():
    # 以openid方式创建用户
    #因为只有openid没用户名所以随机生成用户名
    numnunber = random.randint(999, 900000000)
    try:
        User.objects.get(username=numnunber)
        createname()
    except:
        return numnunber


def get_user_language(telid):
    """ Function to get user's language from redis pool. If not found, get from  SQL .
        If still not found, return default language (CHINESE)
            Return enum of language
        Example:
            lang = get_user_language(update.message.chat_id)
            translater.look_up("Message to tell user", lang)
        """
    user_lang_key = str(telid) + "__settings__language"
    if redisdb.exists(user_lang_key):
        # Get from redis pool
        user_language_settings = redisdb.get(user_lang_key)
        if user_language_settings == "ENGLISH":
            return Language.ENGLISH
        elif user_language_settings == "SIMPLIFIED_CHINESE":
            return Language.SIMPLIFIED_CHINESE
        else:
            raise ValueError('Unknown language key record in redisb ' + user_lang_key)
    else:
        try:
            # Get from SQL
            database_record = user_settings.objects.get(telid=telid)
            if database_record == "EN":
                redisdb.set(user_lang_key, "ENGLISH")
                return Language.ENGLISH
            elif database_record == "SIMPLIFIED_CH":
                redisdb.set(user_lang_key, "SIMPLIFIED_CHINESE")
                return Language.SIMPLIFIED_CHINESE
            else:
                raise ValueError('Cannot find language setting record in SQL ' + user_lang_key)
        except:
            # Still can't find, return default
            return Language.SIMPLIFIED_CHINESE


from netunit import myGet
def set_user_language(telid, enumlang, update, show_msg=True):
    """Set user language into database"""

    key_to_save = []
    if enumlang == Language.ENGLISH:
        key_to_save = "ENGLISH"
    elif enumlang == Language.SIMPLIFIED_CHINESE:
        key_to_save = "SIMPLIFIED_CHINESE"
    else:
        print telid + " can't set " + enumlang + " . No such enum?"
        return

    if len(key_to_save) > 0:
        # Save Redis
        user_lang_key = str(telid) + "__settings__language"
        redisdb.set(user_lang_key, key_to_save)

        # Save SQL
        setting_data = user_settings.objects.get(telid=telid)
        setting_data.language = key_to_save
        setting_data.save()

    # Update keyboard
    # screendata(telid, update)
    downkeydate(telid, update)

    # Send msg to update user
    if show_msg:
        if enumlang == Language.ENGLISH:
            update.message.reply_text('Language settings change to ENGLISH')
        elif enumlang == Language.SIMPLIFIED_CHINESE:
            update.message.reply_text('语言设置为中文')


def get_winners_list(query_objects):
    """Function to return list of winners username """
    usernames = []
    betsizes = []
    telids = []
    for winner_object in query_objects:
        username = Extend_user.objects.get(telid=winner_object.telid).username
        usernames.append(username)

        betsize = winner_object.betquota
        betsizes.append(betsize)

        telids.append(winner_object.telid)

    # Create data frame
    winners_df = pd.DataFrame(data={'telid': telids, 'bet_size': betsizes, 'username': usernames})
    winners_df = winners_df.sort_values('bet_size', ascending=False)

    return winners_df


def create_winners_photo(winners_telid, output_file_loc='./media/output/output.jpg', num_of_image=5):
    """Function to take 5 winner's avatar, and merged them as a single image and saved """
    number_of_photo_to_show = min(len(winners_telid), num_of_image)

    try:
        # Append all the user's avatar image to the list
        list_im = []
        for i in range(0, number_of_photo_to_show):
            telid = winners_telid[i]

            # Check if avatar file exists, if not exists use generic
            headimage = str(telid) + '_head.jpg'
            fileloc = './media/' + headimage

            if os.path.isfile(fileloc):
                fileloc = fileloc
            else:
                generic_image = 'generic_avatar_1234567890.jpg'
                fileloc = './media/' + generic_image
            list_im.append(fileloc)

        imgs = [PIL.Image.open(i) for i in list_im]
        # pick the image which is the smallest, and resize the others to match it (can be arbitrary image shape here)
        min_shape = sorted([(np.sum(i.size), i.size) for i in imgs])[0][1]
        imgs_comb = np.hstack((np.asarray(i.resize(min_shape)) for i in imgs))

        # save that beautiful picture
        imgs_comb = PIL.Image.fromarray(imgs_comb)
        imgs_comb.save(output_file_loc)

        # Send the image to target users
        return True
    except:
        print "Cannot merged winners' images. Removing"
        if os.path.exists(output_file_loc):
            os.remove(output_file_loc)
        return False


def announce_result(bot, job):
    """Function to announce results to bettors"""
    global read_winning_count

    print "Announcement start here- " + str(datetime.datetime.now(tz=pytz.timezone('Asia/Shanghai'))) + \
          "  read_winning_count: " + str(read_winning_count)

    # Fetch result
    netnumberdata = netnumber.objects.get(id=1)
    start_index = netnumberdata.fixednumber
    end_index = netnumberdata.finalnumber

    # Print result
    winners_df = []
    if end_index > start_index:
        #arrow = "上 ▲"
        arrow = "\n       ▲" + \
                "\n      ':'" + \
                "\n    ':::::'" + \
                "\n  ':::::::::'" + \
                "\n':::::::::::::'" + \
                "\n:::::::::::::::"
        winners_df = get_winners_list(bettingup.objects.all())
    elif end_index < start_index:
        #arrow = "下 ▼"
        arrow = "\n:::::::::::::::" + \
                "\n':::::::::::::'" + \
                "\n  ':::::::::'" + \
                "\n    ':::::'" + \
                "\n      ':'" + \
                "\n       '"
        winners_df = get_winners_list(bettingdwon.objects.all())
    else:
        arrow = "DRAW ==============="
        winners_df = pd.DataFrame(data={'telid': [], 'bet_size': [], 'username': []})

    if len(winning.objects.all()) > 0:  # Print
        nuser_up = winning.objects.values_list('userup', flat=True)[0]
        nuser_down = winning.objects.values_list('userdown', flat=True)[0]
        total_bet = winning.objects.values_list('quota', flat=True)[0]
        odds = winning.objects.values_list('theodds', flat=True)[0]

        if odds != 0:
            if end_index > start_index:
                total_up_bet = total_bet / (1 + odds)
                total_down_bet = total_up_bet * odds
            else:
                total_up_bet = odds * total_bet / (1 + odds)
                total_down_bet = total_up_bet / odds

            winners_str = u"\n~~Congratulations to winners~~"
            for i in range(0, len(winners_df)):
                winners_str += "\n" + str(winners_df.iloc[i]['username']) + " , " + str(winners_df.iloc[i]['bet_size'])
            winners_str += "\n~~~~~~~~~~~~~~~~~~~~~~~~"
        else:
            if nuser_up > 0 and nuser_down > 0:
                total_up_bet = "-"
                total_down_bet = "-"
            elif nuser_up > 0 and nuser_down == 0:
                total_up_bet = total_bet
                total_down_bet = 0
            elif nuser_down > 0 and nuser_up == 0:
                total_down_bet = total_bet
                total_up_bet = 0
            else:
                total_up_bet = "-"
                total_down_bet = "-"
            winners_str = "\n "

        msg = 'Up bettors: ' + str(nuser_up) + '\nDown bettors: ' + str(nuser_down) + \
              '\nTotal wager: ' + str(total_bet) + \
              '\nUp wager: ' + str(total_up_bet) + '       Down wager: ' + str(total_down_bet) + \
              '\nWin odds: ' + str(round(odds, 5)) + \
              '\nStart ' + str(start_index) + ',  End ' + str(end_index)
        msg2 = arrow + winners_str

        # Convert message to English and Chinese
        msg_CN = translator.replace_words_in_message(msg, Language.SIMPLIFIED_CHINESE)
        msg_EN = translator.replace_words_in_message(msg, Language.ENGLISH)

        msg2_CN = translator.replace_words_in_message(msg2, Language.SIMPLIFIED_CHINESE)
        msg2_EN = translator.replace_words_in_message(msg2, Language.ENGLISH)

        # Reset
        read_winning_count = 0
    else:
        # Sleep for awhile, and recall again until result if found, or exceed limit
        if read_winning_count < 18:
            time.sleep(0.5)
            announce_result(bot, job)
            read_winning_count += 1
        else:
            msg = '... DEBUG read_winning_count:' + str(read_winning_count)
            msg2 = '.'
            read_winning_count = 0 #Reset

    # Get all up/down bettors, and send them message
    all_telid = list(bettingup.objects.values_list('telid', flat=True))
    all_telid += list(bettingdwon.objects.values_list('telid', flat=True))

    # Get their corresponding language settings
    all_lang_settings = {"telid": Language.SIMPLIFIED_CHINESE}
    for telid in all_telid:
        try:
            settings = get_user_language(telid)
            all_lang_settings[telid] = settings
        except:
            print "Can't get settings for telid: " + str(telid)
            all_lang_settings[telid] = Language.SIMPLIFIED_CHINESE

    # Create winner's photo and save
    symbols = ['']*10
    symbols[0] = '♕'
    symbols[1] = '♔'
    symbols[2] = '♞'
    symbols[3] = '♞'

    top_number = min(len(winners_df), 5)
    top_5name = "前" + str(top_number) + "名 ："
    top_5telid = []
    for i in range(0, top_number):
        top_5name += symbols[i] + str(winners_df.iloc[i]['username']) + "   "
        top_5telid.append(winners_df.iloc[i]['telid'])

    output_file_loc = './media/output/output.jpg'
    is_image_ok = create_winners_photo(winners_telid=top_5telid, output_file_loc=output_file_loc)

    # Spam msg
    for telid in set(all_telid):
        try:
            # Send announcement message
            user_lang_str = all_lang_settings[telid]
            if user_lang_str == Language.ENGLISH:
                sendmessage_async(bot, job, telid, msg_EN, msg2_EN)
            elif user_lang_str == Language.SIMPLIFIED_CHINESE:
                sendmessage_async(bot, job, telid, msg_CN, msg2_CN)
            else:
                sendmessage_async(bot, job, telid, msg_CN, msg2_CN)

            # Send Photo
            if is_image_ok and odds != 0:
                #bot.send_photo(chat_id=telid, photo=open(output_file_loc, 'rb'), caption=top_5name, disable_notification=True)
                sendphoto_async(bot, job, telid, open(output_file_loc, 'rb'), top_5name, True)
        except Exception, e:
            print "Cant send message to this telid " + telid


@run_async
def sendmessage_async(bot, job, telid, msg1, msg2):
    bot.send_message(chat_id=telid, text=msg1)
    bot.send_message(chat_id=telid, text=msg2)


@run_async
def sendphoto_async(bot, job, telid, photo, caption, disable_notification=True):
    bot.send_photo(chat_id=telid, photo=photo, caption=caption, disable_notification=disable_notification)


def announce_result_loop(bot, job):
    """Scheduler to print bet outcome result & Delete"""
    # Run this loop that check for changes of state to 'gamesEnd'
    refresh_interval = 1
    while True:
        first_check_game_not_ended = redisdb.ttl('gamesYeid') > 0
        time.sleep(refresh_interval)

        second_check_game_ended = str(redisdb.ttl('gamesYeid')) == "None"
        if second_check_game_ended and first_check_game_not_ended:   # This check for game state 'JUST' changed
            # DO ANNOUNCEMENT HERE
            # announce_result(bot, job) # Sometimes got problem?
            job.job_queue.run_once(announce_result, when=2)   # Delay 2 secs to give server time

            # Schedule next result-announcement loop
            print "Schedule next announcement loop"
            #job.job_queue.run_once(announce_result_loop, when=25 + 10 - 7)
            job.job_queue.run_once(announce_result_loop, when=place_bet_window_time + rest_window_time- 7)

            # Schedule next STOP-announcement #TODO: Delete this. Can't seem to follow time correctly
            # job.job_queue.run_once(announce_stop, when=25 - 10 - 1)  # earlier one sec
            break


def announce_stop(bot, job):
    """Function to announce STOP betting"""
    announce_time = datetime.datetime.now(tz=pytz.timezone('Asia/Shanghai'))

    msg = "买定离手 " + str(announce_time)
    print 'announcing ' + msg + ' ' + str(announce_time)

    # Get all up/down bettors, and send them message
    all_telid = list(bettingup.objects.values_list('telid', flat=True))
    all_telid += list(bettingdwon.objects.values_list('telid', flat=True))
    for telid in set(all_telid):
        try:
            bot.send_message(chat_id=telid, text=msg)
        except Exception, e:
            print "Cant print 买定离手 to " + telid


# 机器人启动入口
place_bet_window_time = 150 + 30*0
waiting_result_window_time = 30
rest_window_time = 120 + 15*0
def main():
    # This is YCQ
    #updater = Updater(token="695084531:AAFczz_cSkdzx7RefbIsI-iHAKAa38qLbUE")
    updater = Updater(token="556371653:AAHSLPgP536fbOp5YDhhMB9y970UBWiiOa0", workers=64)  # LVH


    #处理start
    updater.dispatcher.add_handler(CommandHandler('start', start, pass_args=True))
    #处理start 的button回调
    updater.dispatcher.add_handler(CallbackQueryHandler(button))
    #处理用户打字回应
    updater.dispatcher.add_handler(MessageHandler(Filters.text, echo))
    updater.dispatcher.add_error_handler(error)

    # Queue for announcement
    #updater.job_queue.run_once(announce_result_loop, when=25 + 10 - 7)
    updater.job_queue.run_once(announce_result_loop, when=place_bet_window_time + rest_window_time - 7)

    # Start the Bot
    updater.start_polling()

    # Run the bot until the user presses Ctrl-C or the process receives SIGINT,
    # SIGTERM or SIGABRT
    updater.idle()



translator = TranslateString()
if __name__ == '__main__':
    main()
    # gevent.spawn(gametime, 5)
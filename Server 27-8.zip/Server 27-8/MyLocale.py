#!/usr/bin/env python
# -*- coding: utf-8 -*-
from enum import Enum
import pandas as pd
import numpy as np
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


class Language(Enum):
    """Define all possible outcome """
    ENGLISH = 0
    SIMPLIFIED_CHINESE = 1


class TranslateString:
    dictionary_df = []

    def __init__(self):
        self.create_dictionary()

        # TODO: !Check dictionary for duplicated key

    def create_dictionary(self):
        """Function to create entire dictionary"""
        key = 'Betting time, good luck! \nTime to stop betting :'
        self.dictionary_df = pd.DataFrame({'Key': key,
                                           'SimplifiedChinese': ['现在是投注时间请您随意投注祝您好运.\n距离停止投注剩余 : '],
                                           'English': [key]})

        key = 'Bet no longer accepted. Please wait for result announcement\nTime to result announcement :'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['投注已停止,下注已无法,请等待开奖.\n开奖时间还剩余 : '],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'This round is over. Please check your record if you have placed bet\nTime to next round :'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['本期投注已开奖请查看开奖记录\n距离下次投注时间 : '],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your balance is : %s x-coin\nSelect your bet amount'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的余额是 : %s X币\n选择您要下注的数额'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your balance is : %s x-coin\nBet UP↑ Total Amount %s'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的余额是 : %s X币\n买涨↑总下注%s'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your balance is : %s x-coin\nBet DOWN↓ Total Amount %s x-coin'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的余额是 : %s X币\n买跌↓总下注 %s X币'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your balance is : %s x-coin\nInsufficient balance to place bet'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的余额是 : %s X币\n余额不足无法下注'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your balance is : %s x-coin\nMinimum bet requirement is 100 x-coin'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的余额是 : %s X币\n投注最少 100 X币起'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = ' sec'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': [' 秒']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'You cancel all up bet.\nReturn %s x-coin'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您以取消本次买涨的所有下注\n反还 %s X币'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'You have not place any bet. Nothing to cancel'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您未下注无需取消'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'You cancel all down bet.\nReturn %s x-coin'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您以取消本次买跌的所有下注\n反还 %s X币'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        # History 历史
        key = "Your recent winners history"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['您的近期获奖历史']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Time   |   x-coin"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['时间   |   X币']})
        self.dictionary_df = self.dictionary_df.append(df2)

        # Screen data
        # '开始下注', '开 奖', '充 值', '收 款'], ['中 文', '翻 墙' ['游戏规则'], ['邀请朋友一起玩']]
        key = 'Start Bet'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['开始下注'] })
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Result'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['开 奖']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Topup'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['充 值']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Cash out'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['收 款']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '中 文 / ENGLISH'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['中 文 / ENGLISH']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'VPN'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['翻 墙']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Game rules'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['游戏规则']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Invite others'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['邀请朋友一起玩']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Welcome to Bitcoin Fun Hour'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['欢迎光临比特娱乐:']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'How to play'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ["游戏玩法"]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'How to topup'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['充值教学']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Hi, I am Bitcoin Bet Bot'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['您好我是比特币投注机器人']})
        self.dictionary_df = self.dictionary_df.append(df2)

        # Reply keyboard
        key = '↑+All in'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['↑+全梭了']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '↓+All in'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['↓+全梭了']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Bet info'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['投注详情']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '↑Bet up'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['↑买涨']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '↓Bet down'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['↓买跌']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '✖↑Cancel'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['✖↑取消']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '✖↓Cancel'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['✖↓取消']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '♜ Homepage'
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['♜主页']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Your betting info\nBalance : %s x-coin\nCurrent round bet:\n↑Up bet %s x-coin\n↓Down bet %s x-coin \n'
        df2 = pd.DataFrame({'Key': key,
                            'SimplifiedChinese': ['您的投注详情\n余额 : %s X币\n当前个人投注如下:\n↑买涨 %s X币\n↓买跌 %s X币 \n'],
                            'English': [key]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = 'Time left to wager: '
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['下注时间: ']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '\nTime to announce result: '
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['\n开奖时间：']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = '\nTime to next round: '
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['\n下一局时间: ']})
        self.dictionary_df = self.dictionary_df.append(df2)

        # Topup messages
        key = "Notice: \nx-coin will be credited to your balance once the transaction is confirmed. " + \
                        "\nExchange rate: 	0.0001 BTC = 100 x-coin "
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['注意: \n认证完毕后，X币就会自动转入账号\n汇率: 	0.0001 比特币 = 100 X币']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Please send Bitcoin to this address \n"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['请把比特币转进以下地址\n']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Address will expire in "
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['地址有效时间']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Address expired. \nPlease do NOT send to the address and " + \
              "request for new address after one minute"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['地址已过期。 \n请不要转账此地址，等待一分钟再重新申请新地址']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Pending your Bitcoin payment to this address \n"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ['等待您的比特币付款，请发送至\n']})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = "Your recent transactions" + \
              "\n Address    |  Num. Confirmation (max is 6) |  x-coin"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': ["您的近期充值历史" + \
                                                  "\n比特币地址     |   确认次数（6次满） |  X币"]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = " (confirmed)"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': [" (确认)"]})
        self.dictionary_df = self.dictionary_df.append(df2)

        key = " (unconfirmed)"
        df2 = pd.DataFrame({'Key': key, 'English': [key],
                            'SimplifiedChinese': [" (未确认)"]})
        self.dictionary_df = self.dictionary_df.append(df2)


    def replace_words_in_message(self, msg, enumlang=Language.SIMPLIFIED_CHINESE):
        """
        :param msg: message to be translated to enumlang
        :param enumlang: target language to translated to
        :return: translated message
        """
        try:
            msg_new = msg
            if enumlang == Language.SIMPLIFIED_CHINESE:
                # Bettors
                msg_new = msg_new.replace("Up bettors", "买涨人数")
                msg_new = msg_new.replace("Down bettors", "买跌人数")
                msg_new = msg_new.replace("Total wager", "总注码")
                msg_new = msg_new.replace("Up wager", "买上注码")
                msg_new = msg_new.replace("Down wager", "买下注码")
                msg_new = msg_new.replace("Win odds", "胜利赔率")
                msg_new = msg_new.replace("Start ", "开")
                msg_new = msg_new.replace("End ", "结")

                # Winners
                msg_new = msg_new.replace("Congratulations to winners", "~~~~~恭喜胜利者~~~~~~")
                msg_new = msg_new.replace("DRAW", "平")

                return msg_new
            elif enumlang == Language.ENGLISH:
                return msg_new
        except:
            print "?? Error when performing replacment"
            return msg


    def look_up(self, msg, enumlang=Language.SIMPLIFIED_CHINESE):
        """ @msg,       Message to lookup
            @enumlang,  language to translate to
        """
        default_lang = 'SimplifiedChinese'
        try:
            ind = np.where(self.dictionary_df["Key"] == msg)[0]
            if enumlang == Language.SIMPLIFIED_CHINESE:
                return self.dictionary_df.iloc[ind]['SimplifiedChinese'][0]
            elif enumlang == Language.ENGLISH:
                return self.dictionary_df.iloc[ind]['English'][0]
            else:
                # Default
                return self.dictionary_df.iloc[ind][default_lang][0]
        except:
            print "Cant translate this: " + msg + "  for " + str(enumlang)
            return msg



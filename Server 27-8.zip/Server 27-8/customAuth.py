# -*- coding: utf-8 -*-
# from django.contrib.auth.models import User
import urllib
import urllib2
from django.contrib.auth.models import User

'''
    需要在settings里配置如下:
    AUTHENTICATION_BACKENDS = (
    #django自带的验证
    'django.contrib.auth.backends.ModelBackend',
    #自定义验证
    'usarextend.customAuth.CustomAuth'
    )
    唯一识别号认证登录
    可以分别传入其中一个参数直接登陆
    方法如
    auth = authenticate(openid=获取的openid)
    login(request, auth)
    或者
    auth = authenticate(openid=获取的phoneid)
    login(request, auth)
'''


class CustomAuth(object):
    def get_user(self, id_):
        try:
            return User.objects.get(pk=id_)
        except User.DoesNotExist:
            return None

    def authenticate(self, authid=None):

        try:
            user = User.objects.get(extend_user__telid=authid)
        except:
            pass

        try:
            if user is not None:
                return user
            return None
        except User.DoesNotExist:
            return None


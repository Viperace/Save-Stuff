#-*- coding: utf-8 -*-

# Create your tests here.
import redis
import time
# from btchtm.netunit import myGet
# redisdb = redis.StrictRedis(host='localhost', port=6379, db=0)

# btcdat=myGet('https://api.coindesk.com/v1/bpi/currentprice/USD.json')
# data=eval(btcdat)
# print data['bpi']['USD']['rate_float']



pool = redis.ConnectionPool(host='localhost', port=6379, decode_responses=True)   # host是redis主机，需要redis服务端和客户端都起着 redis默认端口是6379
redisdb = redis.Redis(connection_pool=pool)
#
# redisdb.set('gametime','start',ex=180)
# while True:
#     time.sleep(1)
#     redisdb.set('gametime',int(redisdb.get('gametime'))+1)
# r.set('gender', 'male')     # key是"gender" value是"male" 将键值对存入redis缓存
# print(r.get('gender'))      # gender 取出键male对应的值
#
# print  r.get("ddd")


# while True:
#     i=0
#     time.sleep(0.2)
#     print i
# import sys
# reload(sys)
import urllib
# from gevent import monkey
# import time
#
# monkey.patch_all()
# import gevent
#
# def f(url):
#     while True:
#         time.sleep(2)
#         print('GET:')
#
#
# gevent.spawn(f, 'http://www.163.org/')
#
#
# while True:
#     time.sleep(1)
#     print 'kkk'


# print not redisdb.ttl('betGameEnd')
# seconds =300
# m, s = divmod(seconds, 60)
# h, m = divmod(m, 60)
# print("%d:%02d:%02d" % (h, m, s))


if __name__ == '__main__':

    pass
# coding:utf-8
from django.conf import settings
from django.db import models

# Create your models here.
class Extend_user(models.Model):
    ext_user = models.OneToOneField(settings.AUTH_USER_MODEL)
    username=models.CharField( u'用户名',max_length=100,blank=True,unique=True)
    pawword=models.CharField( u'密码 ',max_length=100,blank=True)
    telid=models.CharField( u'tel序列号',max_length=100,blank=True,unique=True)
    openid=models.CharField( u'开放平台序列号',max_length=100,blank=True,unique=True)
    xcoin=models.IntegerField( u'心币',null=True, blank=True)
    btcaddress=models.CharField( u'btcaddress',max_length=255,blank=True,unique=True)
    giveusermoney=models.IntegerField( u'首次赠送积分',null=True, blank=True)
    userip=models.CharField( u'用户ip',max_length=100,blank=True)
    country=models.CharField( u'国家',max_length=100,blank=True)
    notice=models.CharField( u'单用户公告',max_length=255,blank=True)
    isreferee=models.BooleanField(u'是否已填入推荐者',)
    # 用来做分享后对方购买给奖励
    upid=models.IntegerField( u'上线id',null=True, blank=True)
    userisrun=models.BooleanField(u'是否封号',)
    moneytime=models.DateTimeField(u'时间',auto_now=True)
    class Meta:
            verbose_name = u"用户管理"
            verbose_name_plural = u"用户管理"


# Settings. 用户设置
class user_settings(models.Model):
    userid = models.IntegerField( u'用户id', null=True, blank=True)
    telid = models.CharField(u'tel序列号', max_length=100, blank=True, unique=True)
    language = models.CharField(u'语言', max_length=100, default='SIMPLIFIED_CHINESE')

    class Meta:
            verbose_name = u"用户设置"
            verbose_name_plural = u"用户设置"


#中奖历史记录
class whistory(models.Model):
    userid=models.IntegerField( u'用户id',null=True, blank=True)
    quota=models.IntegerField( u'中奖获得金额',null=True, blank=True)
    bettime=models.DateTimeField(u'中奖时间',auto_now=True)
    class Meta:
            verbose_name = u"中奖历史"
            verbose_name_plural = u"中奖历史"

#网络指数
class netnumber(models.Model):
    onlinenumber=models.FloatField( u'网络指数',null=True, blank=True)
    finalnumber = models.FloatField(u'结账指数', null=True, blank=True)
    fixednumber=models.FloatField( u'固定指数',null=True, blank=True)
    class Meta:
            verbose_name = u"指数管理"
            verbose_name_plural = u"指数管理"

# 充值历史
class addcapital(models.Model):
    userid=models.IntegerField( u'用户id',null=True, blank=True)
    exchangerate=models.FloatField( u'汇率',null=True, blank=True)
    quota=models.IntegerField( u'充值金额',null=True, blank=True)
    bettime=models.DateTimeField(u'充值时间',auto_now=True)
    class Meta:
            verbose_name = u"充值历史"
            verbose_name_plural = u"充值历史"

# -------游戏完成会清空----------------------------------------------------------------------->
# 投涨
class bettingup(models.Model):
    userid=models.IntegerField( u'用户id',null=True, blank=True,unique=True)
    telid=models.CharField( u'tel序列号',max_length=100,blank=True,unique=True)
    betquota=models.IntegerField( u'投注额度',null=True, blank=True)
    bettime=models.DateTimeField(u'投注时间',auto_now=True)
    class Meta:
            verbose_name = u"投涨"
            verbose_name_plural = u"投涨"
# 投跌
class bettingdwon(models.Model):
    userid=models.IntegerField( u'用户id',null=True, blank=True,unique=True)
    telid=models.CharField( u'tel序列号',max_length=100,blank=True,unique=True)
    betquota=models.IntegerField( u'投注额度',null=True, blank=True)
    bettime=models.DateTimeField(u'投注时间',auto_now=True)
    class Meta:
            verbose_name = u"投跌"
            verbose_name_plural = u"投跌"

#中奖结果
class winning(models.Model):
    userup=models.IntegerField( u'买涨用户数',null=True, blank=True)
    userdown=models.IntegerField( u'买跌用户',null=True, blank=True)
    theodds=models.FloatField( u'赔率数',null=True, blank=True)
    quota=models.IntegerField( u'奖金总额',null=True, blank=True)
    bettime=models.DateTimeField(u'中奖时间',auto_now=True)
    class Meta:
            verbose_name = u"中奖数据"
            verbose_name_plural = u"中奖数据"

# -------游戏完成会清空----------------------------------------------------------------------->
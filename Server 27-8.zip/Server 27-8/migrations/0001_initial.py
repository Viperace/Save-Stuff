# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='addcapital',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('exchangerate', models.FloatField(null=True, verbose_name='\u6c47\u7387', blank=True)),
                ('quota', models.IntegerField(null=True, verbose_name='\u5145\u503c\u91d1\u989d', blank=True)),
                ('bettime', models.DateTimeField(auto_now=True, verbose_name='\u5145\u503c\u65f6\u95f4')),
            ],
            options={
                'verbose_name': '\u5145\u503c\u5386\u53f2',
                'verbose_name_plural': '\u5145\u503c\u5386\u53f2',
            },
        ),
        migrations.CreateModel(
            name='bettingdwon',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(unique=True, null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('telid', models.CharField(unique=True, max_length=100, verbose_name='tel\u5e8f\u5217\u53f7', blank=True)),
                ('betquota', models.IntegerField(null=True, verbose_name='\u6295\u6ce8\u989d\u5ea6', blank=True)),
                ('bettime', models.DateTimeField(auto_now=True, verbose_name='\u6295\u6ce8\u65f6\u95f4')),
            ],
            options={
                'verbose_name': '\u6295\u8dcc',
                'verbose_name_plural': '\u6295\u8dcc',
            },
        ),
        migrations.CreateModel(
            name='bettingup',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(unique=True, null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('telid', models.CharField(unique=True, max_length=100, verbose_name='tel\u5e8f\u5217\u53f7', blank=True)),
                ('betquota', models.IntegerField(null=True, verbose_name='\u6295\u6ce8\u989d\u5ea6', blank=True)),
                ('bettime', models.DateTimeField(auto_now=True, verbose_name='\u6295\u6ce8\u65f6\u95f4')),
            ],
            options={
                'verbose_name': '\u6295\u6da8',
                'verbose_name_plural': '\u6295\u6da8',
            },
        ),
        migrations.CreateModel(
            name='Extend_user',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(unique=True, max_length=100, verbose_name='\u7528\u6237\u540d', blank=True)),
                ('pawword', models.CharField(max_length=100, verbose_name='\u5bc6\u7801 ', blank=True)),
                ('telid', models.CharField(unique=True, max_length=100, verbose_name='tel\u5e8f\u5217\u53f7', blank=True)),
                ('openid', models.CharField(unique=True, max_length=100, verbose_name='\u5f00\u653e\u5e73\u53f0\u5e8f\u5217\u53f7', blank=True)),
                ('xcoin', models.IntegerField(null=True, verbose_name='\u5fc3\u5e01', blank=True)),
                ('btcaddress', models.CharField(unique=True, max_length=255, verbose_name='btcaddress', blank=True)),
                ('giveusermoney', models.IntegerField(null=True, verbose_name='\u9996\u6b21\u8d60\u9001\u79ef\u5206', blank=True)),
                ('userip', models.CharField(max_length=100, verbose_name='\u7528\u6237ip', blank=True)),
                ('country', models.CharField(max_length=100, verbose_name='\u56fd\u5bb6', blank=True)),
                ('notice', models.CharField(max_length=255, verbose_name='\u5355\u7528\u6237\u516c\u544a', blank=True)),
                ('isreferee', models.BooleanField(verbose_name='\u662f\u5426\u5df2\u586b\u5165\u63a8\u8350\u8005')),
                ('upid', models.IntegerField(null=True, verbose_name='\u4e0a\u7ebfid', blank=True)),
                ('userisrun', models.BooleanField(verbose_name='\u662f\u5426\u5c01\u53f7')),
                ('moneytime', models.DateTimeField(auto_now=True, verbose_name='\u65f6\u95f4')),
                ('ext_user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': '\u7528\u6237\u7ba1\u7406',
                'verbose_name_plural': '\u7528\u6237\u7ba1\u7406',
            },
        ),
        migrations.CreateModel(
            name='netnumber',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('onlinenumber', models.FloatField(null=True, verbose_name='\u7f51\u7edc\u6307\u6570', blank=True)),
                ('finalnumber', models.FloatField(null=True, verbose_name='\u7ed3\u8d26\u6307\u6570', blank=True)),
                ('fixednumber', models.FloatField(null=True, verbose_name='\u56fa\u5b9a\u6307\u6570', blank=True)),
            ],
            options={
                'verbose_name': '\u6307\u6570\u7ba1\u7406',
                'verbose_name_plural': '\u6307\u6570\u7ba1\u7406',
            },
        ),
        migrations.CreateModel(
            name='payment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('btcaddress', models.CharField(max_length=255, verbose_name='btcaddress', blank=True)),
                ('exchangerate', models.FloatField(null=True, verbose_name='\u6c47\u7387', blank=True)),
                ('quota', models.IntegerField(null=True, verbose_name='\u5fc3\u5e01', blank=True)),
                ('btc', models.FloatField(null=True, verbose_name='\u6bd4\u7279\u5e01', blank=True)),
                ('creationtime', models.DateTimeField(null=True, verbose_name='\u7533\u8bf7\u65f6\u95f4', blank=True)),
                ('bettime', models.DateTimeField(null=True, verbose_name='\u4ed8\u6b3e\u65f6\u95f4', blank=True)),
                ('ispayment', models.BooleanField(verbose_name='\u662f\u5426\u652f\u4ed8')),
            ],
            options={
                'verbose_name': '\u4ed8\u6b3e\u7ba1\u7406',
                'verbose_name_plural': '\u4ed8\u6b3e\u7ba1\u7406',
            },
        ),
        migrations.CreateModel(
            name='user_settings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('telid', models.CharField(unique=True, max_length=100, verbose_name='tel\u5e8f\u5217\u53f7', blank=True)),
                ('language', models.CharField(default=b'SIMPLIFIED_CHINESE', max_length=100, verbose_name='\u8bed\u8a00')),
            ],
            options={
                'verbose_name': '\u7528\u6237\u8bbe\u7f6e',
                'verbose_name_plural': '\u7528\u6237\u8bbe\u7f6e',
            },
        ),
        migrations.CreateModel(
            name='whistory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userid', models.IntegerField(null=True, verbose_name='\u7528\u6237id', blank=True)),
                ('quota', models.IntegerField(null=True, verbose_name='\u4e2d\u5956\u83b7\u5f97\u91d1\u989d', blank=True)),
                ('bettime', models.DateTimeField(auto_now=True, verbose_name='\u4e2d\u5956\u65f6\u95f4')),
            ],
            options={
                'verbose_name': '\u4e2d\u5956\u5386\u53f2',
                'verbose_name_plural': '\u4e2d\u5956\u5386\u53f2',
            },
        ),
        migrations.CreateModel(
            name='winning',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('userup', models.IntegerField(null=True, verbose_name='\u4e70\u6da8\u7528\u6237\u6570', blank=True)),
                ('userdown', models.IntegerField(null=True, verbose_name='\u4e70\u8dcc\u7528\u6237', blank=True)),
                ('theodds', models.FloatField(null=True, verbose_name='\u8d54\u7387\u6570', blank=True)),
                ('quota', models.IntegerField(null=True, verbose_name='\u5956\u91d1\u603b\u989d', blank=True)),
                ('bettime', models.DateTimeField(auto_now=True, verbose_name='\u4e2d\u5956\u65f6\u95f4')),
            ],
            options={
                'verbose_name': '\u4e2d\u5956\u6570\u636e',
                'verbose_name_plural': '\u4e2d\u5956\u6570\u636e',
            },
        ),
    ]

#-*- coding:utf-8 -*-
import base64
import json
import urllib
import urllib2
from btchtm.aespy import AesCrypt
from btc import settings

# 自带服务器通信密码
def myPost(url,mydata):

        data = {}
        newdic=dict({'password':'ddddd'}, **mydata)
        mydata=base64.b64encode(AesCrypt().pyencrypt(str(newdic)))
        # print mydata
        data['data']=mydata
        #定义post的地址
        post_data = urllib.urlencode(data)
        #提交，发送数据
        headers = {'User-Agent':'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6'}
        reqhead = urllib2.Request(url, headers = headers)
        req = urllib2.urlopen(reqhead, post_data,timeout=60)
        #获取提交后返回的信息
        content = req.read()
        return content


# 需要自己输入密码
def myInputPost(url,mydata):

        data = {}
        mydata=base64.b64encode(AesCrypt().pyencrypt(str(mydata)))
        data['data']=mydata
        print data
        #定义post的地址
        post_data = urllib.urlencode(data)
        #提交，发送数据
        headers = {'User-Agent':'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6'}
        reqhead = urllib2.Request(url, headers = headers)
        req = urllib2.urlopen(reqhead, post_data,timeout=60)
        #获取提交后返回的信息
        content = req.read()
        return content


def myGet(url):
        headers = {'User-Agent':'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.6) Gecko/20091201 Firefox/3.5.6'}
        req = urllib2.Request(url,headers = headers)
        res_data = urllib2.urlopen(req,timeout=60)
        res = res_data.read()
        return res

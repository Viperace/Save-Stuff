# -*- coding: utf-8 -*-
from gevent import monkey
import time

monkey.patch_all()
import gevent

import os
import sys
import platform
import redis

from BetAllocation import BetManager
from btchtm.models import bettingup, bettingdwon, winning
import datetime
import pytz

# -------引入django 模型------->
#如果是linux 返回true

def isLinuxSystem():
    return 'Linux' in platform.system()


if isLinuxSystem():
    sys.path.append(r'/var/www/html/btc')
    os.chdir(r'/var/www/html/btc')
else:
    sys.path.append(r'J:\2017work\django\2018work\telegrambot\btc')
    os.chdir(r'J:\2017work\django\2018work\telegrambot\btc')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'btc.settings')
import django

django.setup()
#-------引入django 模型------->
from btchtm.models import netnumber
from btchtm.netunit import myGet

#pool = redis.ConnectionPool(host='155.254.49.141',password='#$dsd!4ds', port=6379, decode_responses=True)   # host是redis主机，需要redis服务端和客户端都起着 redis默认端口是6379
pool = redis.ConnectionPool(host='localhost', port=6379, decode_responses=True)
redisdb = redis.Redis(connection_pool=pool)



def gametiem(game,yeid,end):
    # 初始化

    redisdb.delete('gamesStart')
    redisdb.delete('gamesYeid')
    redisdb.delete('gamesEnd')
    redisdb.set('gamesEnd','end',ex=end)
    i=2
    redisdb.set('gameBet','no')
    netnumberdata=netnumber.objects.get(id=1)
    netnumberdata.fixednumber=netmumber()
    netnumberdata.save()

    # Init
    bettingup.objects.all().delete()
    bettingdwon.objects.all().delete()
    winning.objects.all().delete()
    while True:

        time.sleep(1)
        if not redisdb.ttl('gamesStart') and i==0:
            redisdb.set('gamesYeid','yeid',ex=yeid)
            redisdb.set('gameBet','no')
            print 'gameyeid--->'
            i=1
        if not redisdb.ttl('gamesYeid') and i==1:
            redisdb.set('gamesEnd','end',ex=end)
            redisdb.set('gameBet','no')
            #这里执行输赢运算---------------------------------------------------------------------------->这个位置加入中奖赔率等算法


            # Extract bettor
            down_bettors = []
            down_betsize = []
            down_bettime = []
            betdownManager = bettingdwon.objects.all()
            for betdownObj in betdownManager:
                down_bettors.append(betdownObj.userid)
                down_betsize.append(betdownObj.betquota)
                down_bettime.append(betdownObj.bettime)

            up_bettors = []
            up_betsize = []
            up_bettime = []
            betupManager = bettingup.objects.all()
            for betupObj in betupManager:
                up_bettors.append(betupObj.userid)
                up_betsize.append(betupObj.betquota)
                up_bettime.append(betupObj.bettime)

            # Check winner/loser and allocate points
            betManager = BetManager(up_bettors, up_betsize, up_bettime,
                                    down_bettors, down_betsize, down_bettime)

            # 开，看谁赢输。分钱
            announce_time = datetime.datetime.now(tz=pytz.timezone('Asia/Shanghai'))
            netnumberdata = netnumber.objects.get(id=1)

            # Decide end number
            end_index = netmumber()
            netnumberdata.finalnumber = end_index
            netnumberdata.save()

            start_index = netnumberdata.fixednumber
            betManager.AllocatePoint(announce_time, start_index, end_index)

            print 'gameend--->'
            i=2
        if not redisdb.ttl('gamesEnd') and i==2:
            redisdb.set('gamesStart','start',ex=game)
            redisdb.set('gameBet','yes')
            try:
                # 如果获取固定指数失败
                netnumberdata=netnumber.objects.get(id=1)
                netnumberdata.fixednumber=netnumberdata.onlinenumber
                netnumberdata.save()
                i=0

                # Reset
                bettingdwon.objects.all().delete()
                bettingup.objects.all().delete()
                winning.objects.all().delete()
                print 'gamestart--->'
            except Exception,e:
                print e
                #失败后不能开局,必须等待120秒后在试
                redisdb.set('gamesEnd','end',ex=end)
                redisdb.set('gameBet','no')
                i=2


        #测试用.可以看到每个时钟的状态
        #print 'gamesStart'+str(redisdb.ttl('gamesStart'))
        #print 'gamesYeid'+str(redisdb.ttl('gamesYeid'))
        #print 'gamesEnd'+str(redisdb.ttl('gamesEnd'))
        #print str(redisdb.get('gameBet'))
        # print i

# 定时获取指数
def getnumber():
    while True:
        try:
            time.sleep(5)
            netnumberdata=netnumber.objects.get(id=1)
            netnumberdata.onlinenumber=netmumber()
            #放一份到内存数据库redisdb
            redisdb.set('btcnumber',netmumber())
            netnumberdata.save()
        except Exception,e:
            print e


# 获取指数方法
def netmumber():
    try:
        btcdat = myGet('https://api.coindesk.com/v1/bpi/currentprice/USD.json')
        data = eval(btcdat)
        # print data['bpi']['USD']['rate_float']
        return data['bpi']['USD']['rate_float']
    except:
        netmumber()


# 本代码依赖 gevent 异步包 redis nosql数据库
#开始游戏进程游戏可下注时间150秒,30秒锁注时间第180秒开奖,剩余120秒聊天.以此循环
# gamesStart,gamesYeid,gamesEnd 是时种分别对应各时间,会自动导计时,倒计时完成后这个对象为None
#gameBet游戏是否可下注'yes'可下'no不以下'
# 查询当前对象剩余时间 例:redisdb.ttl('gamesStart')

# gevent.spawn(gametiem,150,30,120)
# gevent.spawn(gametiem, 25, 20, 10)

place_bet_window_time = 150 + 30*0
waiting_result_window_time = 30
rest_window_time = 120 + 15*0
gevent.spawn(gametiem, place_bet_window_time, waiting_result_window_time, rest_window_time)

#开始获取网络BTC指数5秒一次
gevent.spawn(getnumber)

while True:
    time.sleep(10000)
    print 'kkk'
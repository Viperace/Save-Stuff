#coding:utf-8
from __future__ import absolute_import
import os
import sys
import platform

# -------引入django 模型------->
#如果是linux 返回true
from systembf.mysqlbf import sqlbfrun


def isLinuxSystem():
    return 'Linux' in platform.system()

if isLinuxSystem():
    sys.path.append(r'/var/www/html/btc')
    os.chdir(r'/var/www/html/btc')
else:
    sys.path.append(r'J:\2017work\django\2018work\telegrambot\btcserver')
    os.chdir(r'J:\2017work\django\2018work\telegrambot\btcserver')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'btc.settings')
import django
django.setup()
#-------引入django 模型------->
from celery import shared_task
from celery import platforms

platforms.C_FORCE_ROOT = True




# 备份数据库队列
@shared_task
def ssmysqlbf():
    # sqlbfrun()
    print "ssmysqlbf_run"
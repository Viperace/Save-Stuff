#coding:utf-8

def globalall(request):
    return {
        'xcoin':' xcoin ',
        'homename':' 比特娱乐',
        #自定义的汇率
        'exchangerate':1000000,
    }



#!/usr/bin/env python
# -*- coding: utf-8 -*-
from netunit import myGet
from pay.models import Payhistory
from btchtm.models import Extend_user
# from MyLocale import TranslateString, Language  # Localization
import json
import redis

pool = redis.ConnectionPool(host='localhost', port=6379, decode_responses=True)
redisdb = redis.Redis(connection_pool=pool)


class BitcoinPayment:
    def __init__(self):
        self.data = []

    @staticmethod
    def is_payment_sent(telid):
        """ Check if user completed payment """
        try:
            url = "http://155.254.49.141:8111/pay/scanajax/?telid=" + str(telid)
            jsonurl = myGet(url)
            print jsonurl
            pay_status_json = json.loads(jsonurl)
            status = pay_status_json['btcovertime']
            if status == 'over':
                return True
            elif status == 'run':
                return False
            else:
                print 'Unknown payment status ' + status
                return False
        except:
            print 'Unknown error when checking is_payment_sent. Request from server '
            return True

    @staticmethod
    def get_payment_address(telid):
        """Function to request wallet address and get time left"""
        url = 'http://155.254.49.141:8111/pay/buybtc/?data=buy&telid=' + str(telid)
        jsonurl = myGet(url)
        #jsonurl = urllib.urlopen(url)
        j = json.loads(jsonurl)
        btc_address = j['getbtcaddress']
        time_left_in_sec = j['btcovertime']
        # usd_per_btc = j['usd'] ??
        # cny = j['cny'] ??

        return btc_address, time_left_in_sec

    @staticmethod
    def topup_process(bot, update, translator, user_lang, offset_sec=20):
        '''Initiate topup process for the user. Will Print the btc address to the user'''
        telid = update.message.chat_id

        general_msg = translator.look_up(
                        "Notice: \nx-coin will be credited to your balance once the transaction is confirmed. " \
                        "\nExchange rate: 	0.0001 BTC = 100 x-coin ", user_lang)

        # Key to save to redisb
        user_btcaddress_key = str(telid) + "__btcaddress"

        # Check if got unexpired pending payment
        if BitcoinPayment.is_payment_sent(telid):
            # Get fresh address for user to send
            new_address, time_left = BitcoinPayment.get_payment_address(telid)
            print 'time left before int  ' + str(time_left)
            time_left_sec = int(time_left)

            # Save the address to redisb memory. Future pulling
            expire_time = time_left_sec - offset_sec  # Second before expired.
            redisdb.setex(user_btcaddress_key, new_address, expire_time)
            print 'Set time : ' + str(expire_time)

            # Reply user
            update.message.reply_text(translator.look_up('Please send Bitcoin to this address \n', user_lang))
            update.message.reply_text(new_address)
            update.message.reply_text(translator.look_up('Address will expire in ', user_lang) + str(time_left) +
                                      translator.look_up(' sec', user_lang))
        else:
            # Load the  btc address and time left
            user_btcaddress = redisdb.get(user_btcaddress_key)
            time_left = redisdb.ttl(user_btcaddress_key)
            print 'check time_left : ' + str(time_left)

            if time_left is None:
                # Lock period, wait for 'get_payment_address' to gen 'over' status
                update.message.reply_text(translator.look_up("Address expired. \nPlease do NOT send to the address and "
                                                             "request for new address after one minute", user_lang))
            else:
                # Still got time, reply user the same address
                update.message.reply_text(general_msg)
                update.message.reply_text(translator.look_up('Pending your Bitcoin payment to this address \n', user_lang) + user_btcaddress)
                update.message.reply_text(translator.look_up('Address will expire in ', user_lang) + str(time_left) +
                                          translator.look_up(' sec', user_lang))


    @staticmethod
    def show_payment_history(bot, update, translator, user_lang):
        """Function to pull sql database for user's history """
        # Get mapping of telid to userid
        try:
            Extend_userdata = Extend_user.objects.get(telid=update.message.chat_id)
            userid = Extend_userdata.id
        except:
            print "Cant get sql user in 'show_payment_history' "
            update.message.reply_text("Server busy...")
            return

        # Extract most recent 3 history (order by ID)
        nhistory = 3
        payhistorydata = Payhistory.objects.filter(userid=userid)
        last_ten = payhistorydata.order_by('-id')[:nhistory]
        last_ten_in_ascending_order = reversed(last_ten)


        # Concat message and print out
        # Address ....  5 .... (confirm)
        msg = translator.look_up("Your recent transactions" + \
              "\n Address    |  Num. Confirmation (max is 6) |  x-coin", user_lang) # Title
        for hist in last_ten_in_ascending_order:    # Actual content
            msg += "\n" + hist.address + ",  " + str(hist.confirmations)

            if hist.confirmations >= 6:
                msg += translator.look_up(" (confirmed)", user_lang) + " , " + str(int(hist.value / 100))
            else:
                msg += translator.look_up(" (unconfirmed)", user_lang) + " , " + str(int(hist.value / 100))

        update.message.reply_text(msg)
